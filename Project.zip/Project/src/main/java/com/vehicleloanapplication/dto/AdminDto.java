package com.vehicleloanapplication.dto;

public class AdminDto  {
	private String email;
	private String name;
	private String password;

}
