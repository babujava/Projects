package com.vehicleloanapplication.exceptions;



public class LoanApplicationException extends Exception {
    public LoanApplicationException(String message)
    {
        super(message);
    }

 

}