package com.vehicleloanapplication.exceptions;

public class PasswordResetException extends Exception {
	

		public PasswordResetException(String msg) {
			super(msg);

		}
	}


