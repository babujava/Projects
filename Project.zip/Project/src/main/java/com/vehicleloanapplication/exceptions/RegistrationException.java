package com.vehicleloanapplication.exceptions;



public class RegistrationException  extends Exception
{
	/**
	 * @param msg
	 *            : Error message
	 */
	public RegistrationException(String msg) {
		super(msg);
	}
}
