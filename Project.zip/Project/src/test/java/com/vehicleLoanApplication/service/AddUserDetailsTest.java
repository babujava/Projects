package com.vehicleLoanApplication.service;

 

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

 

import java.util.Arrays;
import java.util.Optional;
import java.util.List;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

 

import com.vehicleloanapplication.dao.AccountJPARepository;
import com.vehicleloanapplication.dao.UserDetailsJPARepository;
import com.vehicleloanapplication.dao.UserRegisterJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.AccountEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.model.UserRegistrationEntity;
import com.vehicleloanapplication.service.AccountServiceImpl;
import com.vehicleloanapplication.service.UserDetailsServiceImpl;

 

@SpringBootTest
public class AddUserDetailsTest {

    @MockBean
    UserDetailsJPARepository userDetailsRepo;
    @MockBean
    UserRegisterJPARepository userRegisterRepo;
    @Autowired
    UserDetailsServiceImpl Service;
    //ADDING CORRECT USER DETAILS
    @Test
    @DisplayName("Test - Add User details by email - successful")
    public void correctDetailstPassed(){
         String email = "hello@gmail.com";
        UserDetailsEntity user=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
                5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
        UserRegistrationEntity userRegistration=new UserRegistrationEntity("hello@gmail.com",22,"Female","7799854820", "RubyElite", "HTER3456",user);
        Mockito.doReturn(Arrays.asList(user)).when(userRegisterRepo).save(userRegistration);
        try {
            List<UserDetailsEntity> list=Service.addUserDetails(user, email);
            assertEquals(1,list.size());
        }
             catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    }


 