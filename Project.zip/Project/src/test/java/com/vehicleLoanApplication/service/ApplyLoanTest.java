package com.vehicleLoanApplication.service;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.vehicleloanapplication.dao.LoanApplicationJPARepository;
import com.vehicleloanapplication.model.LoanApplicationEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.service.LoanApplicationServiceImpl;

@SpringBootTest
public class ApplyLoanTest {
    
	
	@MockBean
	LoanApplicationJPARepository loanRepo;
	
	
	@Autowired
	LoanApplicationServiceImpl loanService;
	
	
	//null object passed
	@Test
	@DisplayName("Test apply loan - null value entered")
	public void nullLoanObjectPassed() {
		LoanApplicationEntity loan=null;
		List<LoanApplicationEntity> list=null;
		Optional<List<LoanApplicationEntity>> list1=null;
		Mockito.when(loanRepo.findAll()).thenReturn(list);
		list1=loanService.applyLoan(loan, 1);
	    assertNull(list);	
		
	}
	
	//Apply loan successful
	@Test
	@DisplayName("Test apply loan successful")
	public void applyLoanSuccessful() {
		Optional<List<LoanApplicationEntity>> list=Optional.of(new ArrayList<LoanApplicationEntity>());
		UserDetailsEntity user=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
			5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
		LoanApplicationEntity loan=new LoanApplicationEntity("12ht45", 200000.0,10,5.0,5000000,
			LocalDate.now(),"PENDING", "Mercedes", "red", "cls", 4, 5000000.0,
			6000000, user);
		Mockito.when(loanRepo.findAll()).thenReturn(Arrays.asList(loan));
		list=loanService.applyLoan(loan,1);
		assertEquals(list.get(),Arrays.asList(loan));
	}
	
	
	
}
