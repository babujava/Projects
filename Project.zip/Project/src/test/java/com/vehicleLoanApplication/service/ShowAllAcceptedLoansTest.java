package com.vehicleLoanApplication.service;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.bind.MethodArgumentNotValidException;

import com.vehicleloanapplication.dao.LoanApplicationJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.LoanApplicationEntity;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.service.LoanApplicationServiceImpl;

@SpringBootTest
public class ShowAllAcceptedLoansTest {
	@BeforeEach
	public void setup() {
		
		
	}

	@MockBean
	LoanApplicationJPARepository loanRepo;
				
	@Autowired
	LoanApplicationServiceImpl loanService;
	
	/* Test case for no Accepted Loans */
	
	@Test
	@DisplayName("Show All Accepted Loans - No Accepted Loans")
	public void showNoRejectedLoans()
	{
		List<LoanApplicationEntity> loans=new ArrayList<LoanApplicationEntity>();
		UserDetailsEntity user=new UserDetailsEntity("Elite, Santhosapuram", "Telangana","Hyderabad", "600073", "Full time",
				5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
	   LoanApplicationEntity loan=new LoanApplicationEntity("AP03", 500000.0,30,8.0,7000000,
			LocalDate.now(),"Pending", "Lamborgini", "skyblue", "clsas", 8, 5000000.0,
			6000000, user);
	   try {
			Mockito.when(loanRepo.showAllAcceptedLoans()).thenReturn(loans);
			loans=loanService.getAllAcceptedLoans();
		} catch (RecordNotFoundException e) {
			// TODO Auto-generated catch block
			
			assertEquals(e.getMessage(),"No Approved Loans");	 
		}


	} 
	
	/*Test Case for one accepted loans */
	
	@Test
	@DisplayName("Show All Accepted Loans - Accepted Loans exists") 
	public void pendingLoansExists()
	{
		List<LoanApplicationEntity> loans2=new ArrayList<LoanApplicationEntity>();
		UserDetailsEntity user=new UserDetailsEntity("Ruby , Santhosapuram", "Andhra Pradesh","Gudivada", "6400", "Part time",
				6000000.0, "abcd.url", "hgfh.url", "salaryslips.url", "adreesproofs.url");
	   LoanApplicationEntity loan=new LoanApplicationEntity("Ts03", 100000.0,20,9.0,8000000,
			LocalDate.now(),"Accepted", "Indigo", "Yellow", "clsas", 8, 6000000.0,
			7000000, user);
	   
	   try {
			Mockito.when(loanRepo.showAllAcceptedLoans()).thenReturn(Arrays.asList(loan)); 
			loans2=loanService.getAllAcceptedLoans();
		} catch (RecordNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	   assertEquals(1,loans2.size()); 

	}   

 
}