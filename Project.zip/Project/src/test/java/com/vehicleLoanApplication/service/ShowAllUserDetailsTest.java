package com.vehicleLoanApplication.service;

 


import static org.junit.jupiter.api.Assertions.assertEquals;

 


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

 


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
//import org.springframework.web.bind.MethodArgumentNotValidException;

 

import com.vehicleloanapplication.dao.UserDetailsJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.model.UserDetailsEntity;
import com.vehicleloanapplication.service.UserDetailsServiceImpl;

 

@SpringBootTest
public class ShowAllUserDetailsTest {
    @BeforeEach
    public void setup() {

 


    }
    @MockBean
    UserDetailsJPARepository userDetailsRepo;

 

    @Autowired
    UserDetailsServiceImpl Service;
    //SHOWING USER DETAILS
    @Test
    @DisplayName("Show UserDetails- successful")
    public void showAllUserDetailsSuccessfull() throws RecordNotFoundException {
        List<UserDetailsEntity> list=new ArrayList<UserDetailsEntity>();
        UserDetailsEntity user1=new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
                5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
        UserDetailsEntity user2=new UserDetailsEntity("Alan Walker, Aryapuram", "Andhra Pradesh","Vijayawada", "533002", "Part time",
                70000.0, "def.url", "ijk.url", "salaryslip.url", "adreesproof.url");
        Mockito.when(userDetailsRepo.findAll()).thenReturn(Arrays.asList(user1,user2));
        list=Service.showAllUserDetails();
        assertEquals(list.size(),2);
    }
    //NULL USER DETAILS
    @Test
    @DisplayName("Show UserDetails- Null")
    public void NullUserDetailsEntered() throws RecordNotFoundException {
        List<UserDetailsEntity> userDetails=new ArrayList<UserDetailsEntity>();
        List<UserDetailsEntity> user=null;
        Mockito.when(userDetailsRepo.findAll()).thenReturn(user);
        userDetails=Service.showAllUserDetails();
        assertEquals(user,userDetails);
    }
    //NO USERS FOUND
    @Test
    @DisplayName("Show All Users - no user found")
    public void noUserFound() {
        
        List<UserDetailsEntity> list=new ArrayList<UserDetailsEntity>();
        List<UserDetailsEntity> returnedList=new ArrayList<UserDetailsEntity>();
        
        
            Mockito.when(userDetailsRepo.findAll()).thenReturn(list);
            
            try {
                returnedList = Service.showAllUserDetails();
            } catch (RecordNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            assertEquals(list,returnedList);
    
    }
}
 