package com.vehicleLoanApplication.service;

 

import java.util.ArrayList;
import java.util.Arrays;

 

import com.vehicleloanapplication.model.UserDetailsEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

 

import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.web.bind.MethodArgumentNotValidException;
import com.vehicleloanapplication.dao.UserDetailsJPARepository;
import com.vehicleloanapplication.exceptions.RecordNotFoundException;
import com.vehicleloanapplication.service.UserDetailsServiceImpl;
@SpringBootTest
public class ShowUserDetailsInformationByUserIdTest {
    @BeforeEach
    public void setup() {
    }
    @MockBean
    UserDetailsJPARepository userDetailsRepo;
    @Autowired
    UserDetailsServiceImpl Service;
    @Test
    @DisplayName("Show User details by Id- no UserId entered")
    public void noUserIdEntered()  {
        
        int user_id = 0;
        Optional<UserDetailsEntity> user = Optional.of(new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
                5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url"));
        Optional<UserDetailsEntity> user1 = null;
        UserDetailsEntity user2 = null;
        Mockito.when(userDetailsRepo.findById(user_id)).thenReturn(user1);
        try {
            user2 = Service.showUserDetailsInformationByUserId(user_id);
        } catch (RecordNotFoundException e) {
           
        }
        assertEquals(user1,user2);
        
    }
    
    @Test
    @DisplayName("Test - show User details by UserId - UserId Entered")
    public void correctObjectPassed(){
        int user_id=1;
        Optional<UserDetailsEntity> userDetailsEntity = null;
        
        UserDetailsEntity user = new UserDetailsEntity("Ruby Elite, Santhosapuram", "Tamil Nadu","Chennai", "600073", "Full time",
                5000000.0, "abc.url", "hgf.url", "salaryslip.url", "adreesproof.url");
        
        Mockito.when(userDetailsRepo.saveAndFlush(user)).thenReturn(user);
        Mockito.when(userDetailsRepo.findById(user_id)).thenReturn(Optional.of(user));
        
        try {
            userDetailsEntity = Optional.of(Service.showUserDetailsInformationByUserId(user_id));
        } catch (RecordNotFoundException e) {
            
        }
        assertEquals(userDetailsEntity.get(),user);

 

    }

 

    @Test
    @DisplayName("Show UserDetails By UserId-  UserDetails not present")
    public void UserDetailsNotEntered()  {
        int user_id=1;
        UserDetailsEntity userDetails=null;
        Optional<UserDetailsEntity> user=null;
        Mockito.when(userDetailsRepo.findById(user_id)).thenReturn((user));
        try {
			userDetails=Service.showUserDetailsInformationByUserId(user_id);
		} catch (RecordNotFoundException e) {
			assertEquals(e.getMessage(),"No Records Found");
		}
        
        
}
}
 