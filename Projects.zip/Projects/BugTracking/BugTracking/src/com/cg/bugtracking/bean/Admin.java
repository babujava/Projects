package com.cg.bugtracking.bean;

public class Admin {

	private long adminId;
	private String adminName;
	private String adminContact;
}
