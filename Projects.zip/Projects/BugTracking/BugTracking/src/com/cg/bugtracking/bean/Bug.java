package com.cg.bugtracking.bean;

import java.util.Date;

public class Bug {
	
	private long bugId;
	private String bugDesc;
	private String status;
	private Date startDate;
	private Date endDate;
	private String assignee;
	private String type;
	private String priority;
	private long projectId;

}
