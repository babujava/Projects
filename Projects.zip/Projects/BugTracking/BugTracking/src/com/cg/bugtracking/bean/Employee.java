package com.cg.bugtracking.bean;

public class Employee {
	private long empId;
	private String empName;
	private String email;
	private String contactNo;
	private long projectId;

}
