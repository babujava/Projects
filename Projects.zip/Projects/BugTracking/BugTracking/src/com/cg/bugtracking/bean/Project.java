package com.cg.bugtracking.bean;

import java.util.List;

public class Project {
	
	private long projectId;
	private String projectOwner;
	private List<Employee> members;
	private String status;
	
}
