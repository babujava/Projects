package com.cg.bugtracking.bean;

public class User {
	
	private long userId;
	private String password;
	private String role;

}
