package com.cg.bugtracking.dao;

import java.util.List;

import com.cg.bugtracking.bean.Bug;

public interface IBugRepository {
	public Bug createBug();
	public Bug updateBug(long id);
	public Bug getBug(long id);
	public List<Bug> getAllBugs();
	public List<Bug> getAllBugsByStatus(String status);
	public Bug deleteBug(long id);


}
