package com.cg.bugtracking.dao;

import java.util.List;

import com.cg.bugtracking.bean.Project;

public interface IProjectRepository {
	
	public Project addProject(Project project);
	public Project deleteProject(long id);
	public Project updateProject(long id, Project project);
	public Project getProject(long id);
	public List<Project> getAllProjects();

}
