package com.cg.bugtracking.dao;

import com.cg.bugtracking.bean.User;

public interface IUserRepository {
	public User createUser(User user);
	public User login(User user);
	public User logout(User user);

}
