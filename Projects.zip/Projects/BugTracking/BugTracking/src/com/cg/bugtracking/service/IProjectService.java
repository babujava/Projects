package com.cg.bugtracking.service;

import java.util.List;

import com.cg.bugtracking.bean.Project;

public interface IProjectService {

	public Project addProject(Project project);
	public Project deleteProject(long id);
	public Project updateProject(long id, Project project);
	public Project getProject(long id);
	public List<Project> getAllProjects(); 
}
