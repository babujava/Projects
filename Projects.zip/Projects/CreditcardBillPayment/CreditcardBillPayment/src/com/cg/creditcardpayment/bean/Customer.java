package com.cg.creditcardpayment.bean;

import java.time.LocalDate;

public class Customer {
	
	private String userId;
	private String name;
	private String email;
	private String contactNo;
	private  LocalDate dob;
	private Address address;

}
