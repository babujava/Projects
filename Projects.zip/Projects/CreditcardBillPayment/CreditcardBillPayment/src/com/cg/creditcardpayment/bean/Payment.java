package com.cg.creditcardpayment.bean;

public class Payment {
	private long paymentId;
	private String type;
	private String status;
	private CreditCard card;

}
