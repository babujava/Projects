package com.capgemini.exception;

public class DuplicateDonorException extends Exception {

}
