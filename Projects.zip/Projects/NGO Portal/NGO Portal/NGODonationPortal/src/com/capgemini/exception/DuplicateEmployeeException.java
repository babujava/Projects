package com.capgemini.exception;

public class DuplicateEmployeeException extends Exception {

}
