package com.capgemini.exception;

public class NoSuchDonorException extends Exception {

}
