package com.capgemini.model;

public class Address {
	private int addressId;
	private String city;
	private String state;
	private String pin;
	private String landmark;
}
