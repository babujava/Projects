package com.capgemini.model;

public class Admin {
	private int adminId;
	private String adminUsername;
	private String adminPassword;
	
}
