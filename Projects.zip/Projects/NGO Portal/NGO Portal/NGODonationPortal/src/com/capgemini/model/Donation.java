package com.capgemini.model;

import java.util.Date;

public class Donation {
	private int donationId;
	private Donor donor;
	private DonationItem item;
	private double donationAmount;
	private Date donationDate;
}
