package com.capgemini.model;

public class DonationBox {
	private String ngoName;
	private String registrationNumber;
	private String accountNumber;
	private double totalCollection;
}
