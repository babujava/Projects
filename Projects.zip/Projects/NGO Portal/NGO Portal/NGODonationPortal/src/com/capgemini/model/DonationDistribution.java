package com.capgemini.model;

import java.util.Date;

public class DonationDistribution {
	private int distributionId;
	private NeedyPeople person;
	private DonationItem item;
	private Employee distributedBy;
	private double amountDistributed;
	private Date dateOfDistribution;
	private Date approvalOrRejectedDate;
	private DonationDistributionStatus status;
}
