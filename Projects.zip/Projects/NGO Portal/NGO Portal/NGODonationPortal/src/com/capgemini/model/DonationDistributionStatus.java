package com.capgemini.model;

public enum DonationDistributionStatus {
	PENDING, APPROVED, REJECTED;
}
