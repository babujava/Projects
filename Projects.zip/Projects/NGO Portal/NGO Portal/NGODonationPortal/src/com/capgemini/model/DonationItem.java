package com.capgemini.model;

public class DonationItem {
	private int itemId;
	private DonationType item;
	private String itemDescription;
}
