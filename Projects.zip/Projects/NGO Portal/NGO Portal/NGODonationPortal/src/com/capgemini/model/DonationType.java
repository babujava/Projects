package com.capgemini.model;

public enum DonationType {
	MONEY, CLOTHS, BOOKS, EDIBLE, OTHER
}
