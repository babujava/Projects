package com.capgemini.model;

public class Donor {
	private int donorId;
	private String donorName;
	private String donorEmail;
	private String donorPhone;
	private String donorUsername;
	private String donorPassword;
	private Address address;
}
