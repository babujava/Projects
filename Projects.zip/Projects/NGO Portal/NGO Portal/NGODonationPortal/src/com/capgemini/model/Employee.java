package com.capgemini.model;

public class Employee {
	private int employeeId;
	private String employeeName;
	private String email;
	private String phone;
	private Address address;
	private String username;
	private String password;
}
