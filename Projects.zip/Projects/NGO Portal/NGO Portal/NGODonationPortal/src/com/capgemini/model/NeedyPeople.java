package com.capgemini.model;

public class NeedyPeople {
	private int needyPersonId;
	private String needyPersonName;
	private String phone;
	private double familyIncome;
	private Address address;
}
