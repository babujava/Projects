package com.cg.gasbooking.entity;

public abstract class AbstractUser {
	private String username;
	private String password;
	private String mobileNumber;
	private String email;
}