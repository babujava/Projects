package com.cg.gasbooking.entity;

public class Admin extends AbstractUser {
	private int adminId;
}