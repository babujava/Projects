package com.cg.gasbooking.entity;

public class Bank  {
	private int bankId;
	private String bankName;
	private String address;
}