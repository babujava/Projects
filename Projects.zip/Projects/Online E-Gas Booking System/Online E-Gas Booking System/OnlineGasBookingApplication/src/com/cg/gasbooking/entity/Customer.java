package com.cg.gasbooking.entity;

public class Customer extends AbstractUser {
	private int customerId;
	private int cylinderId;
	private int bankID;
	private int accountNo;
	private String ifscNo;
	private String pan;
}