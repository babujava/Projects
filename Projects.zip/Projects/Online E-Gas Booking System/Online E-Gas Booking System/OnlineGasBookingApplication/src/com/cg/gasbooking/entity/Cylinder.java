package com.cg.gasbooking.entity;

public class Cylinder {
	private int cylinderId;
	private String type;
	private float weight;
	private String strapColor;
	private float price;
}