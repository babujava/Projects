package com.cg.gasbooking.entity;

import java.time.LocalDate;

public class SurrenderCylinder {
	private int surrenderId;
	private LocalDate surrenderDate;
	private Customer customer;
	private Cylinder cylinder;
}