package com.cg.gasbooking.exception;

public class AdminNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5595964428948080655L;

}
