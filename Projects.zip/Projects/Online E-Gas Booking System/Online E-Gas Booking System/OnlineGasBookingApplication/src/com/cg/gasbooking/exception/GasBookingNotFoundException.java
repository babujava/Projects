package com.cg.gasbooking.exception;

public class GasBookingNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -9090587718141879101L;

}
