package com.cg.gasbooking.exception;

public class SurrenderCylinderNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 914569459626622748L;

}
