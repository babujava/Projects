package com.capgemini.exception;

public class DuplicateCustomerException extends Exception {

}
