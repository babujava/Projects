package com.capgemini.exception;

public class InvalidCredintialException extends Exception {

}
