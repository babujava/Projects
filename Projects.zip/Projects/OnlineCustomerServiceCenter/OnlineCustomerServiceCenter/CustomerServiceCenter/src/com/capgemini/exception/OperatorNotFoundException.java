package com.capgemini.exception;

public class OperatorNotFoundException extends Exception {

}
