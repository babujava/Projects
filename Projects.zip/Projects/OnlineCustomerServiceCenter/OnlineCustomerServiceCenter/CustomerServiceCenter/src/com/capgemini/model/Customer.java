package com.capgemini.model;

public class Customer {
	private int customerId;
	private String firstName;
	private String lastName;
	private String email;
	private String mobile;
	private String city;
}
