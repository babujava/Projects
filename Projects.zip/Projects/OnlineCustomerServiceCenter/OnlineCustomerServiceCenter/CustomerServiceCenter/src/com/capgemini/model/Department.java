package com.capgemini.model;

public class Department {
	private int departmentId;
	private String departmentName;
	
}
