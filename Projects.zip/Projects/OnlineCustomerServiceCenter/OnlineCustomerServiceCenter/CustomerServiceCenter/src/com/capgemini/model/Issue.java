package com.capgemini.model;

public class Issue {
	private String issueId;
	private String issueType;
	private String description;
	private String issueStatus;
	
}
