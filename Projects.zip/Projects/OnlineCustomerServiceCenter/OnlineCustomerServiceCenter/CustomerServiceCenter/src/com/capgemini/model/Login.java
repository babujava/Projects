package com.capgemini.model;

public class Login {
	// userid - customer, operatorid - operator
	private int username;
	private String password;
	private UserType type;
	private boolean isActive;
}
