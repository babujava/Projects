package com.capgemini.model;

public class Operator {
	private int operatorId;
	private String firstName;
	private String lastName;
	private String email;
	private String mobile;
	private String city;
	
	private Department department;
}
