package com.capgemini.model;

import java.util.Date;

public class Solution {
	private int solutionId;
	private String solutionDescription;
	private Date solutionDate;
	
	private Operator specilist;
	private Issue issue;
}
