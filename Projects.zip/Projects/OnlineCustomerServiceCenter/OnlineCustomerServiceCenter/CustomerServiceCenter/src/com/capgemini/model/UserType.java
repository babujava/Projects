package com.capgemini.model;

public enum UserType {
	CUSTOMER, OPERATOR
}
